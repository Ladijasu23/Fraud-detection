
# 🚗 Auto Insurance Fraud Detection - Streamlit App

This Streamlit web application allows you to **train a machine learning model** using your own insurance claim dataset and then **predict fraudulent claims** on new data. It uses a `RandomForestClassifier` from scikit-learn and provides model evaluation metrics including **Precision**, **Recall**, and **F1-score**.

---

## 📦 Features

- 📂 Upload custom **training** and **test** CSV files
- 🔍 Automatic preprocessing and label encoding
- 📊 Model Training and **Evaluation Report** on validation set
- ⚙️ **Random Forest Classifier** for binary classification
- 📈 Prediction output with downloadable CSV results
- 💻 Beautifully rendered **classification report**

---

## 🛠 How to Run

1. Install dependencies:

```bash
pip install streamlit pandas scikit-learn
```

2. Run the Streamlit app:

```bash
streamlit run app.py
```

---

## 📁 File Structure

```
.
├── app.py             # Main Streamlit application
├── README.md          # Project documentation (this file)
└── requirements.txt   # Python dependencies (optional)
```

---

## 📋 Input File Requirements

### ✅ Training CSV:
- Must contain a column named `Fraud_Ind` as the label.
- Optionally can have `Claim_ID`, which will be ignored.

### ✅ Test CSV:
- Must contain a column named `Claim_ID`.
- Should match the features of the training data (except `Fraud_Ind`).

---

## 📊 Model Evaluation Output

Includes metrics like:

| Label | Precision | Recall | F1-score | Support |
|-------|-----------|--------|----------|---------|
| N     | 1.00      | 1.00   | 1.00     | 5996    |
| Y     | 1.00      | 1.00   | 1.00     | 2004    |

Accuracy, Macro avg, and Weighted avg are also displayed.

---

## 📥 Output

- ✅ Predictions are shown on the UI.
- 💾 One-click **Download CSV** button for saving results.

---

## 📝 License

This project is licensed under the MIT License.
