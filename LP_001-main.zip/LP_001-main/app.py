import streamlit as st
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from sklearn.preprocessing import LabelEncoder

st.set_page_config(page_title="🚗 Auto Insurance Fraud Detection", layout="centered")

st.title("🚗 Auto Insurance Fraud Detection - Train and Predict")

train_file = st.file_uploader("📂 Upload Training Data CSV", type="csv")
test_file = st.file_uploader("📂 Upload Test Data CSV (with Claim_ID)", type="csv")

def generate_markdown_table(df):
    markdown = "| Class | Precision | Recall | F1-Score | Support |\n"
    markdown += "|:------|----------:|--------:|---------:|--------:|\n"
    for idx, row in df.iterrows():
        markdown += f"| {idx} | {row['precision']:.2f} | {row['recall']:.2f} | {row['f1-score']:.2f} | {int(row['support'])} |\n"
    return markdown

if train_file and test_file:
    train_df = pd.read_csv(train_file)
    test_df = pd.read_csv(test_file)

    st.subheader("📊 Training Data Preview")
    st.dataframe(train_df.head())

    st.subheader("📊 Test Data Preview")
    st.dataframe(test_df.head())

    if 'Fraud_Ind' not in train_df.columns or 'Claim_ID' not in test_df.columns:
        st.error("❗ Training file must contain 'Fraud_Ind' and test file must contain 'Claim_ID'.")
    else:
        if 'Claim_ID' in train_df.columns:
            train_df = train_df.drop(columns=['Claim_ID'])

        X = train_df.drop(['Fraud_Ind'], axis=1)
        y = train_df['Fraud_Ind']

        encoders = {}
        for col in X.select_dtypes(include='object').columns:
            le = LabelEncoder()
            X[col] = le.fit_transform(X[col].astype(str))
            encoders[col] = le

        X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

        model = RandomForestClassifier()
        model.fit(X_train, y_train)

        val_preds = model.predict(X_val)
        report = classification_report(y_val, val_preds, output_dict=True)
        df_report = pd.DataFrame(report).transpose()

        st.subheader("✅ Model Evaluation on Validation Split")
        st.markdown(generate_markdown_table(df_report.loc[['N', 'Y', 'accuracy', 'macro avg', 'weighted avg']]))

        test_ids = test_df['Claim_ID']
        X_test = test_df.drop(['Claim_ID'], axis=1)

        for col in X_test.select_dtypes(include='object').columns:
            if col in encoders:
                le = encoders[col]
                X_test[col] = X_test[col].map(lambda s: le.transform([s])[0] if s in le.classes_ else -1)
            else:
                st.warning(f"⚠️ Column '{col}' not present in training data. Dropped.")
                X_test = X_test.drop(columns=[col])

        X_test = X_test[X.columns]

        test_preds = model.predict(X_test)
        output = pd.DataFrame({'Claim_ID': test_ids, 'Fraud_Ind': test_preds})

        st.subheader("🔍 Prediction Output")
        st.dataframe(output.head())

        csv = output.to_csv(index=False).encode()
        st.download_button("⬇️ Download Predictions CSV", data=csv, file_name="predictions.csv", mime='text/csv')